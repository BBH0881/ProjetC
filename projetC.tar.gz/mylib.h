
void load(char* s);
void loadaf(char* s);
void loadf(char* s);
int search(char *recherche);
int afficher(char *fic);